#pragma once

//#ifndef false
//  #define false   0
//#endif

//#ifndef true
//  #define true    1
//#endif

//#ifndef bool
//  #define bool int
//#endif

// #ifdef _WIN32
// #endif
